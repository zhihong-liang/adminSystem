import{_ as e,o as c,c as o}from"./index-a825e4e6.js";const r={};function t(n,s){return c(),o("div")}const _=e(r,[["render",t]]);export{_ as default};
