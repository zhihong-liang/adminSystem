import{_ as o}from"./authorizeInfo.vue_vue_type_script_setup_true_lang-5b3edb5a.js";import"./index-a825e4e6.js";import"./el-tab-pane-93416f58.js";import"./infoBox-d388f93f.js";export{o as default};
