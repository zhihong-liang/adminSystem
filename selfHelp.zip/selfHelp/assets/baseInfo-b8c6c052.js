import{_ as o}from"./baseInfo.vue_vue_type_script_setup_true_lang-4fa3292c.js";import"./index-a825e4e6.js";import"./infoBox-d388f93f.js";export{o as default};
