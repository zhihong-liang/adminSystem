import{_ as e,o as c,c as o}from"./index-195fce8b.js";const n={};function r(t,s){return c(),o("div",null," home ")}const a=e(n,[["render",r]]);export{a as default};
