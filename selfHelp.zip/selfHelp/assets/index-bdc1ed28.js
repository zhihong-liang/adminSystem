import{d as e,j as o,o as t,c as a}from"./index-195fce8b.js";const n={class:"logManage-root"},l=e({__name:"index",setup(s){return o([]),(c,r)=>(t(),a("div",n,"log页面"))}});export{l as default};
