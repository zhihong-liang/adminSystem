import{_ as o}from"./authorizeInfo.vue_vue_type_script_setup_true_lang-7c09b0d0.js";import"./index-195fce8b.js";import"./el-tab-pane-582fcd33.js";import"./infoBox-706e6058.js";export{o as default};
