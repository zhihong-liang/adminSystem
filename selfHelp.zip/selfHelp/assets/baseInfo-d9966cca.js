import{_ as o}from"./baseInfo.vue_vue_type_script_setup_true_lang-27993b07.js";import"./index-195fce8b.js";import"./infoBox-706e6058.js";export{o as default};
