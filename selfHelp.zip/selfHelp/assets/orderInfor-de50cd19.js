import{_ as m}from"./orderInfor.vue_vue_type_script_setup_true_lang-ff162275.js";import"./index-a825e4e6.js";export{m as default};
