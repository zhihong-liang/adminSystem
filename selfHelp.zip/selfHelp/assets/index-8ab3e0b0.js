import{_ as e,o as c,c as n}from"./index-a825e4e6.js";const o={};function r(t,s){return c(),n("div",null," 主题管理 ")}const a=e(o,[["render",r]]);export{a as default};
