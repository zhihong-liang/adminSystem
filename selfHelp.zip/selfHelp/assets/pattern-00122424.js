const d=/^1[3-9]\d{9}$/,s=/^\d{3}-?\d{8}$|^\d{4}-\d{7}$|^1[3-9]\d{9}$/,o=/^[1-9]\d*$/;export{o as i,d as m,s as p};
