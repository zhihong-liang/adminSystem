import{_ as e,o as c,c as n}from"./index-195fce8b.js";const o={};function r(t,s){return c(),n("div",null,"状态码管理")}const a=e(o,[["render",r]]);export{a as default};
